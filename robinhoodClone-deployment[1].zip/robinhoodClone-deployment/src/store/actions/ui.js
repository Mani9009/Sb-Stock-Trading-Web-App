export const HIDE_FORM = "HIDE_FORM";
export const SHOW_FORM = "SHOW_FORM";

export const showForm = () => ({ type: SHOW_FORM });
export const hideForm = () => ({ type: HIDE_FORM });
