import React from 'react'

const NotFound = props =>
<h1>
    Page not found
</h1>
;

export default NotFound;